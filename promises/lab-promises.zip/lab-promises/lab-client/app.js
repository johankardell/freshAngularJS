(function(){
	angular
		.module('app',[])
		.controller( 'appCtrl', AppCtrl )
		.service('dataService', DataService );

	AppCtrl.$inject = ['$scope','dataService'];

	function AppCtrl($scope, dataService){
		$scope.user = null;
		$scope.products = [];

		// do call to DataService here..  use api or json files, up to you
	}

	DataService.$inject = ['$http'];

	function DataService($http){
		return {
			getUser : getUser,
			getProductsByUser : getProductsByUser
		};

		function getUser(){
			// fill in the missing code to fetch a user
		}

		function getProductsByUser(userId){
			// fill in the missing code to fetch products by a user id
		}
	}
})();
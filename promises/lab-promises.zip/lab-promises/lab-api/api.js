var express = require('express'),
	_ = require('lodash');

var app = express();

var products = [
	{
		name : "tomato",
		id : 1,
		userid : 1
	},
	{
		name : "cucumber",
		id : 2,
		userid : 1
	},
	{
		name : "books",
		id : 3,
		userid : 2
	}
];

function getProductsByUser(userId){
	var result = _.filter(products, { userid : userId });
	return result;
}

app.get('/user', function(req, res){
	console.log("calling user/");

	res.json({
		id : 1,
		name : "kalle",
	});
});

app.get('/products/:userId', function(req, res){
	console.log("calling products/ with " + req.params.userId );

	res.json(getProductsByUser( parseInt(req.params.userId) ));
});

app.listen(3000);
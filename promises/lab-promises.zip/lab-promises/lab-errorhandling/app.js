(function(){
	'use strict';

	angular
		.module('app',[])
		.controller('appCtrl', AppCtrl);

	AppCtrl.$inject = ['$scope','$q'];

	function AppCtrl($scope, $q){
		getData().then(successCallback, errorCallback);

		getData()
			.then(successCallback)
			.catch(catchCallback);

		function promiseThatOnlyCatchcallbackCanHandle(){
			var deferred = $q.defer();
			
			throw { name : 'I crashed' };

			return deferred.promise;
		}

		function promiseThatWillReject(){
			var deferred = $q.defer();
			deferred.reject( 'something went wrong' );

			return deferred.promise;
		}	

		function promiseThatWillResolve(){
			var deferred = $q.defer();
			deferred.resolve( 'some data' );

			return deferred.promise;
		}

		function errorCallback(err){
			console.log(err);
		}

		function catchCallback(crashedReason){
			console.log(crashedReason);
		}
	}

})();
do npm install on api
do bower install on clients